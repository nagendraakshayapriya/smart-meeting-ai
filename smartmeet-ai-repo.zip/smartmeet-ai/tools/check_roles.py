import re

with open("pages/notes.html", "r", encoding="utf-8") as f:
    text = f.read()

matches = re.findall(r'id=["\']([^"\']*(?:pane|role|manager|dev|client)[^"\']*)["\']', text, re.IGNORECASE)
print("IDs in notes.html matching pane/role/manager/dev/client:", matches)

# Also let's check lines mentioning role
for idx, line in enumerate(text.splitlines()):
    if any(k in line.lower() for k in ["role", "manager", "developer", "client"]):
        print(f"{idx+1}: {line[:100]}")
