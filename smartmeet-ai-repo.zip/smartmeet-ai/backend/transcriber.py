"""
SmartMeet AI - Whisper Speech-to-Text Transcriber
Uses faster-whisper for local, real-time multilingual speech recognition.
"""

import os
from typing import Optional, Dict, Any, List
from faster_whisper import WhisperModel

_MODEL_CACHE: Dict[str, WhisperModel] = {}


def get_whisper_model(model_size: Optional[str] = None) -> WhisperModel:
    """Loads and caches faster-whisper model with intelligent device selection."""
    size = model_size or os.getenv("WHISPER_MODEL", "base").strip() or "base"
    if size not in _MODEL_CACHE:
        import shutil
        has_usable_cuda = False
        try:
            import ctranslate2
            if ctranslate2.get_cuda_device_count() > 0:
                # Ensure NVIDIA cuBLAS runtime DLL is present
                if shutil.which("cublas64_12.dll") or shutil.which("cublas64_11.dll"):
                    has_usable_cuda = True
        except Exception:
            pass

        if has_usable_cuda:
            try:
                print(f"[Transcriber] Initializing faster-whisper model '{size}' on CUDA (float16)...")
                _MODEL_CACHE[size] = WhisperModel(size, device="cuda", compute_type="float16")
                print(f"[Transcriber] Model '{size}' ready on CUDA.")
                return _MODEL_CACHE[size]
            except Exception as cuda_err:
                print(f"[Transcriber] CUDA initialization failed ({cuda_err}), falling back to CPU (int8)...")

        print(f"[Transcriber] Loading faster-whisper model '{size}' on CPU (int8)...")
        _MODEL_CACHE[size] = WhisperModel(size, device="cpu", compute_type="int8")
        print(f"[Transcriber] Model '{size}' ready on CPU.")
    return _MODEL_CACHE[size]


def format_timestamp(seconds: float) -> str:
    """Formats seconds into MM:SS or HH:MM:SS."""
    total_sec = max(0, int(round(seconds)))
    hours = total_sec // 3600
    minutes = (total_sec % 3600) // 60
    secs = total_sec % 60
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def transcribe_audio(
    wav_path: str,
    language: Optional[str] = None,
    model_size: Optional[str] = None
) -> Dict[str, Any]:
    """
    Transcribes audio using faster-whisper.
    Returns:
    {
        "transcript": [{"start": 0.0, "end": 4.5, "time": "00:00", "seconds": 0, "speaker": "Speaker 1", "text": "..."}],
        "full_text": "...",
        "language": "en",
        "language_probability": 0.98,
        "duration": 12.3
    }
    """
    if not os.path.exists(wav_path):
        raise FileNotFoundError(f"Audio file not found: {wav_path}")

    model = get_whisper_model(model_size)

    # Normalize language parameter (auto-detect if empty or "auto")
    clean_lang = None
    if language and language.strip().lower() not in ["auto", "detect", "default", ""]:
        clean_lang = language.strip().lower()
        # Map full names if provided
        lang_map = {
            "english": "en",
            "tamil": "ta",
            "hindi": "hi",
            "malayalam": "ml",
            "telugu": "te",
            "kannada": "kn",
            "spanish": "es",
            "french": "fr",
            "german": "de"
        }
        clean_lang = lang_map.get(clean_lang, clean_lang[:2])

    print(f"[Transcriber] Transcribing '{wav_path}' (requested language: {clean_lang or 'auto-detect'})...")

    try:
        segments, info = model.transcribe(
            wav_path,
            language=clean_lang,
            beam_size=5,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500)
        )
    except Exception as e:
        err_str = str(e).lower()
        if "cublas" in err_str or "cuda" in err_str or "dll" in err_str:
            print(f"[Transcriber] CUDA runtime error ({e}). Retrying with CPU (int8)...")
            size = model_size or os.getenv("WHISPER_MODEL", "base").strip() or "base"
            model = WhisperModel(size, device="cpu", compute_type="int8")
            _MODEL_CACHE[size] = model
            try:
                segments, info = model.transcribe(
                    wav_path,
                    language=clean_lang,
                    beam_size=5,
                    vad_filter=True,
                    vad_parameters=dict(min_silence_duration_ms=500)
                )
            except Exception as cpu_err:
                raise RuntimeError(f"Whisper transcription failed on CPU: {str(cpu_err)}") from cpu_err
        else:
            raise RuntimeError(f"Whisper transcription failed: {str(e)}") from e

    transcript_chunks: List[Dict[str, Any]] = []
    text_pieces: List[str] = []

    current_speaker_idx = 1
    last_end = 0.0

    for seg in segments:
        text = seg.text.strip()
        if not text:
            continue

        # If there is a significant silence pause (> 2.0s) between utterances,
        # alternate speaker turn between Speaker 1 and Speaker 2 (no fictional names)
        if last_end > 0 and (seg.start - last_end) > 2.2:
            current_speaker_idx = 2 if current_speaker_idx == 1 else 1

        chunk = {
            "start": round(seg.start, 2),
            "end": round(seg.end, 2),
            "seconds": int(round(seg.start)),
            "time": format_timestamp(seg.start),
            "speaker": f"Speaker {current_speaker_idx}",
            "text": text
        }
        transcript_chunks.append(chunk)
        text_pieces.append(text)
        last_end = seg.end

    full_text = " ".join(text_pieces).strip()

    if not transcript_chunks or not full_text:
        raise RuntimeError("No speech detected in the uploaded file.")

    detected_lang = info.language if hasattr(info, "language") else (clean_lang or "en")
    lang_prob = round(info.language_probability, 4) if hasattr(info, "language_probability") else 1.0

    print(f"[Transcriber] Completed. Detected language: {detected_lang} (prob: {lang_prob}), chunks: {len(transcript_chunks)}")

    return {
        "transcript": transcript_chunks,
        "full_text": full_text,
        "language": detected_lang,
        "language_probability": lang_prob,
        "duration": round(info.duration, 2) if hasattr(info, "duration") else round(last_end, 2)
    }
