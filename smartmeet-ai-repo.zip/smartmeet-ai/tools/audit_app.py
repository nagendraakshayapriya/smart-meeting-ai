import glob
import re
import os

html_files = sorted(glob.glob("*.html") + glob.glob("pages/*.html"))

print("=== 1. AUDITING LINKS (HREF) ===")
for html in html_files:
    dir_name = os.path.dirname(html)
    with open(html, "r", encoding="utf-8") as f:
        content = f.read()
    
    # find all href="..."
    hrefs = re.findall(r'href=["\']([^"\']+)["\']', content)
    for h in hrefs:
        if h.startswith("#") or h.startswith("http") or h.startswith("mailto:") or h.startswith("javascript:"):
            continue
        # Strip query string or hash
        clean_h = h.split("?")[0].split("#")[0]
        if not clean_h:
            continue
        target_path = os.path.normpath(os.path.join(dir_name, clean_h))
        if not os.path.exists(target_path):
            print(f"BROKEN LINK in {html}: href='{h}' -> resolved to non-existent '{target_path}'")

print("\n=== 2. AUDITING SCRIPT.JS ELEMENT IDS ===")
with open("script.js", "r", encoding="utf-8") as f:
    js_content = f.read()

# find all document.getElementById('...')
get_ids = set(re.findall(r'getElementById\(["\']([^"\']+)["\']\)', js_content))
# find all querySelector('#...')
qs_ids = set(re.findall(r'querySelector\(["\']#([^"\'>\s\.\,\:\(\)]+)["\']\)', js_content))

all_js_ids = get_ids.union(qs_ids)

# Collect all IDs from HTML files
html_ids = {}
for html in html_files:
    with open(html, "r", encoding="utf-8") as f:
        content = f.read()
    ids_in_file = set(re.findall(r'id=["\']([^"\']+)["\']', content))
    html_ids[html] = ids_in_file

all_existing_ids = set()
for ids in html_ids.values():
    all_existing_ids.update(ids)

missing_ids = all_js_ids - all_existing_ids
print(f"Total IDs referenced in script.js: {len(all_js_ids)}")
print(f"Total IDs defined across HTML: {len(all_existing_ids)}")
print(f"IDs in script.js NOT found in ANY HTML file: {missing_ids}")

print("\n=== 3. AUDITING HTML BUTTONS / INPUTS WITHOUT JS HANDLERS OR EVENT LISTENERS ===")
for html in html_files:
    with open(html, "r", encoding="utf-8") as f:
        content = f.read()
    interactive_ids = re.findall(r'<(?:button|input|select|a)[^>]*\bid=["\']([^"\']+)["\']', content)
    missing_in_js = [i for i in interactive_ids if i not in js_content and not i.startswith("nav")]
    if missing_in_js:
        print(f"Unused interactive IDs in {html}: {missing_in_js}")
