"""
SmartMeet AI - Audio Extractor
Extracts 16 kHz mono 16-bit PCM WAV audio from any video or audio file using FFmpeg.
"""

import os
import shutil
import subprocess
import re
import wave


def get_ffmpeg_executable() -> str:
    """Finds the system ffmpeg or falls back to imageio_ffmpeg bundled binary."""
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        return system_ffmpeg
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as e:
        raise RuntimeError(
            "FFmpeg executable not found. Please install FFmpeg or install imageio-ffmpeg."
        ) from e


def extract_audio(input_path: str, output_wav_path: str) -> dict:
    """
    Extracts audio from video/audio input to 16kHz mono 16-bit PCM WAV.
    Returns metadata dictionary including duration_seconds and channels.
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input media file not found: {input_path}")

    ffmpeg_bin = get_ffmpeg_executable()

    # Ensure output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(output_wav_path)), exist_ok=True)

    # Command: 16 kHz, 1 channel (mono), 16-bit PCM WAV
    cmd = [
        ffmpeg_bin,
        "-y",
        "-i", input_path,
        "-vn",
        "-ac", "1",
        "-ar", "16000",
        "-sample_fmt", "s16",
        output_wav_path
    ]

    process = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace"
    )

    if process.returncode != 0:
        err_msg = process.stderr.strip() or "Unknown FFmpeg error"
        if "does not contain any stream" in err_msg.lower() or "no audio stream" in err_msg.lower():
            raise RuntimeError("No audio track found in the uploaded file.")
        raise RuntimeError(f"Audio extraction failed: {err_msg[:400]}")

    if not os.path.exists(output_wav_path) or os.path.getsize(output_wav_path) < 100:
        raise RuntimeError("Extracted audio file is empty or corrupted. The video may not contain any audible track.")

    duration_seconds = 0.0
    try:
        with wave.open(output_wav_path, "rb") as wf:
            frames = wf.getnframes()
            rate = wf.getframerate()
            if rate > 0:
                duration_seconds = frames / float(rate)
    except Exception:
        # Fallback to parsing duration from ffmpeg stderr
        match = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)", process.stderr)
        if match:
            hours, mins, secs = match.groups()
            duration_seconds = int(hours) * 3600 + int(mins) * 60 + float(secs)

    return {
        "wav_path": output_wav_path,
        "duration_seconds": round(duration_seconds, 2),
        "sample_rate": 16000,
        "channels": 1
    }
