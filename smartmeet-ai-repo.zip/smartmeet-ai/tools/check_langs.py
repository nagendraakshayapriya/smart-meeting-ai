import glob
import re

for p in sorted(glob.glob("*.html") + glob.glob("pages/*.html")):
    with open(p, "r", encoding="utf-8") as f:
        content = f.read()
    langs = re.findall(r'data-lang="([^"]+)"', content)
    print(f"{p}: {langs}")
