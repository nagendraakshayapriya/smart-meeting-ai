"""
SmartMeet AI - Production Backend Server (FastAPI)
Provides real meeting audio extraction, faster-whisper transcription,
and transcript-only AI meeting notes synthesis.
"""

import os
import sys
import time
import shutil
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, UploadFile, File, Form, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from backend.audio_extractor import extract_audio, get_ffmpeg_executable
from backend.transcriber import transcribe_audio, get_whisper_model
from backend.ai_analyzer import analyze_transcript
from backend.job_manager import job_manager

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
TEMP_DIR = BASE_DIR / "backend_temp"
TEMP_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title="SmartMeet AI Backend",
    description="Real Speech-to-Text Meeting Processing Engine",
    version="2.0.0"
)

# Enable CORS for local development and live servers
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def run_pipeline(
    job_id: str,
    media_path: str,
    filename: str,
    title: Optional[str] = None,
    language: Optional[str] = None
) -> None:
    """Synchronous pipeline executed inside a background thread/task."""
    try:
        # Step 1: Extract Audio
        job_manager.update_job(
            job_id=job_id,
            status="extracting_audio",
            stage="extracting_audio",
            progress=20,
            message=f"Extracting 16kHz mono audio track from '{filename}' with FFmpeg..."
        )

        job_dir = Path(media_path).parent
        wav_path = str(job_dir / "audio_16k.wav")

        audio_meta = extract_audio(media_path, wav_path)
        duration_sec = audio_meta.get("duration_seconds", 0.0)

        # Step 2: Transcribing speech
        job_manager.update_job(
            job_id=job_id,
            status="transcribing",
            stage="transcribing",
            progress=50,
            message=f"Transcribing spoken speech using faster-whisper (model: {os.getenv('WHISPER_MODEL', 'base')})..."
        )

        transcription = transcribe_audio(wav_path, language=language)

        # Step 3: Analyzing transcript
        job_manager.update_job(
            job_id=job_id,
            status="analyzing",
            stage="analyzing",
            progress=80,
            message="Analyzing transcript: extracting decisions, action items, participants, and sentiment..."
        )

        user_title = title if title and title.strip() else ""
        analysis = analyze_transcript(
            transcript_text=transcription["full_text"],
            chunks=transcription["transcript"],
            user_title=user_title,
            language=transcription["language"]
        )

        # Step 4: Finalizing notes
        job_manager.update_job(
            job_id=job_id,
            status="finalizing",
            stage="finalizing",
            progress=95,
            message="Finalizing meeting deliverables and formatting notes..."
        )

        clean_ext = Path(filename).suffix.lower()
        is_video = clean_ext in [".mp4", ".mov", ".webm", ".mkv", ".avi"]
        dur_min = max(1, round((duration_sec or transcription.get("duration", 60)) / 60))

        meeting_id = f"meet-{int(time.time() * 1000)}"
        result = {
            "id": meeting_id,
            "jobId": job_id,
            "title": analysis.get("title") or (user_title or filename),
            "fileName": filename,
            "mediaType": "video" if is_video else "audio",
            "mediaUrl": f"/api/media/{job_id}/{Path(media_path).name}",
            "date": time.strftime("%b %d, %Y"),
            "duration": f"{dur_min} min",
            "durationSeconds": duration_sec or transcription.get("duration", 0),
            "participants": len(analysis.get("participants", [])),
            "participantNames": analysis.get("participantNames", []),
            "status": "Processed",
            "category": "Uploaded Recording",
            "language": transcription.get("language", "en"),
            "languageProbability": transcription.get("language_probability", 1.0),
            "summary": analysis.get("summary", ""),
            "keyPoints": analysis.get("keyPoints", []),
            "decisions": analysis.get("decisions", []),
            "actionItems": analysis.get("actionItems", []),
            "sentiment": analysis.get("sentiment", {}),
            "topics": analysis.get("topics", []),
            "transcript": transcription.get("transcript", []),
            "rawTranscriptText": transcription.get("full_text", ""),
            "roleSummaries": analysis.get("roleSummaries", {}),
            "multilingual": analysis.get("multilingual", {})
        }

        job_manager.update_job(
            job_id=job_id,
            status="completed",
            stage="completed",
            progress=100,
            message="Meeting notes generated successfully from authentic speech!",
            result=result
        )

    except Exception as e:
        print(f"[Pipeline Error for job {job_id}]: {e}")
        job_manager.fail_job(job_id, str(e))


@app.get("/api/health")
def health_check():
    """Health check endpoint confirming FFmpeg and Whisper availability."""
    try:
        ffmpeg_bin = get_ffmpeg_executable()
        ffmpeg_ok = bool(ffmpeg_bin and os.path.exists(ffmpeg_bin))
    except Exception:
        ffmpeg_ok = False
        ffmpeg_bin = "Not found"

    model_name = os.getenv("WHISPER_MODEL", "base")
    return {
        "status": "online",
        "ffmpeg": {
            "available": ffmpeg_ok,
            "path": ffmpeg_bin
        },
        "whisper": {
            "model": model_name,
            "backend": "faster-whisper"
        },
        "ai_keys": {
            "gemini": bool(os.getenv("GEMINI_API_KEY")),
            "openai": bool(os.getenv("OPENAI_API_KEY"))
        }
    }


@app.post("/api/process-meeting")
async def process_meeting(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    title: Optional[str] = Form(None),
    language: Optional[str] = Form("auto")
):
    """
    Accepts video or audio file upload and enqueues real speech-to-text processing.
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="Missing uploaded file name.")

    ext = Path(file.filename).suffix.lower()
    allowed = {".mp4", ".mov", ".webm", ".mkv", ".avi", ".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
    if ext not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format '{ext}'. Allowed formats: {', '.join(sorted(allowed))}"
        )

    job_id = job_manager.create_job(file.filename, media_type="video" if ext in [".mp4", ".mov", ".webm", ".mkv", ".avi"] else "audio")
    job_dir = TEMP_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    safe_filename = f"source{ext}"
    saved_path = job_dir / safe_filename

    # Save uploaded file
    try:
        with open(saved_path, "wb") as f:
            while chunk := await file.read(1024 * 1024):  # 1MB chunks
                f.write(chunk)
    except Exception as e:
        job_manager.fail_job(job_id, f"Failed to save uploaded file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"File save error: {str(e)}")

    if not os.path.exists(saved_path) or os.path.getsize(saved_path) == 0:
        job_manager.fail_job(job_id, "Uploaded file was empty.")
        raise HTTPException(status_code=400, detail="Uploaded file was empty.")

    # Enqueue pipeline in background
    background_tasks.add_task(
        run_pipeline,
        job_id=job_id,
        media_path=str(saved_path),
        filename=file.filename,
        title=title,
        language=language
    )

    return {
        "job_id": job_id,
        "status": "queued",
        "message": "File received. Processing pipeline started in background."
    }


@app.get("/api/process-meeting/{job_id}")
def get_meeting_status(job_id: str):
    """Returns current status, progress, stage, message, error, or final result."""
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Processing job not found.")
    return job


@app.get("/api/media/{job_id}/{filename}")
def stream_media(job_id: str, filename: str):
    """Streams uploaded media file for video playback."""
    job_dir = TEMP_DIR / job_id
    media_file = job_dir / filename
    if not media_file.exists():
        raise HTTPException(status_code=404, detail="Media file not found.")
    return FileResponse(str(media_file))


# Mount static assets, pages, and root directory for unified single-server deployment
app.mount("/assets", StaticFiles(directory=str(BASE_DIR / "assets")), name="assets")
app.mount("/pages", StaticFiles(directory=str(BASE_DIR / "pages")), name="pages")

@app.get("/")
def serve_index():
    """Serve main index.html at root."""
    return FileResponse(str(BASE_DIR / "index.html"))

@app.get("/index.html")
def serve_index_html():
    return FileResponse(str(BASE_DIR / "index.html"))

@app.get("/style.css")
def serve_css():
    return FileResponse(str(BASE_DIR / "style.css"), media_type="text/css")

@app.get("/script.js")
def serve_js():
    return FileResponse(str(BASE_DIR / "script.js"), media_type="application/javascript")

@app.get("/acceptance_test_meeting.mp4")
def serve_sample_video():
    video_path = BASE_DIR / "acceptance_test_meeting.mp4"
    if video_path.exists():
        return FileResponse(str(video_path), media_type="video/mp4")
    raise HTTPException(status_code=404, detail="Sample video not found.")

@app.get("/test_speech.wav")
def serve_sample_audio():
    audio_path = BASE_DIR / "test_speech.wav"
    if audio_path.exists():
        return FileResponse(str(audio_path), media_type="audio/wav")
    raise HTTPException(status_code=404, detail="Sample audio not found.")



if __name__ == "__main__":
    import uvicorn
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    print(f"Starting SmartMeet AI Backend at http://{host}:{port}")
    uvicorn.run("backend.main:app", host=host, port=port, reload=True)
