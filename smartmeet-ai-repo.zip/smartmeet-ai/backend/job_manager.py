"""
SmartMeet AI - Background Job Manager
Manages job queue, progress stages, error reporting, and completed results.
"""

import time
import uuid
import threading
from typing import Dict, Any, Optional

class JobManager:
    def __init__(self):
        self._jobs: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def create_job(self, file_name: str, media_type: str = "video") -> str:
        job_id = f"job-{uuid.uuid4().hex[:12]}"
        now = time.time()
        with self._lock:
            self._jobs[job_id] = {
                "job_id": job_id,
                "file_name": file_name,
                "media_type": media_type,
                "status": "queued",
                "stage": "queued",
                "progress": 5,
                "message": "Meeting job queued for processing...",
                "error": None,
                "result": None,
                "created_at": now,
                "updated_at": now
            }
        return job_id

    def update_job(
        self,
        job_id: str,
        status: str,
        progress: int,
        message: str,
        stage: Optional[str] = None,
        error: Optional[str] = None,
        result: Optional[Dict[str, Any]] = None
    ) -> None:
        with self._lock:
            if job_id not in self._jobs:
                return
            job = self._jobs[job_id]
            job["status"] = status
            job["progress"] = max(0, min(100, progress))
            job["message"] = message
            if stage:
                job["stage"] = stage
            if error is not None:
                job["error"] = error
            if result is not None:
                job["result"] = result
            job["updated_at"] = time.time()

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else None

    def fail_job(self, job_id: str, error_message: str) -> None:
        self.update_job(
            job_id=job_id,
            status="error",
            progress=0,
            message=f"Processing failed: {error_message}",
            stage="error",
            error=error_message
        )

# Global singleton
job_manager = JobManager()
