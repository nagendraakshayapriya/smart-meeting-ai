# SmartMeet AI

Upload a meeting recording (video or audio) and get real, transcript-based meeting notes: summary, key points, decisions, action items, participants, topics and sentiment.

## Pipeline
1. **Audio extraction**: FFmpeg converts any media to 16 kHz mono WAV (`backend/audio_extractor.py`)
2. **Transcription**: local speech-to-text with faster-whisper (`backend/transcriber.py`)
3. **Analysis**: Gemini if `GEMINI_API_KEY` is set, otherwise a local deterministic analyzer that only uses what was actually said (`backend/ai_analyzer.py`)
4. **Jobs**: background job queue with progress stages (`backend/job_manager.py`)

## Run locally
```bash
pip install -r requirements.txt
cp .env.example .env     # optional: add GEMINI_API_KEY, change WHISPER_MODEL
python -m backend.main
```
Open http://127.0.0.1:8000. The frontend (`index.html`, `style.css`, `script.js`) is served by the same server. Health check: `/api/health`.

## API
- `POST /api/process-meeting`: upload a file (`file`, optional `title`, `language`)
- `GET /api/process-meeting/{job_id}`: status, progress and final result
- `GET /api/media/{job_id}/{filename}`: stream the uploaded media

Supported formats: mp4, mov, webm, mkv, avi, mp3, wav, m4a, aac, flac, ogg.

## Tech
Python, FastAPI, faster-whisper, FFmpeg, httpx.

## Dev tools
`tools/` has small audit scripts for the frontend (run from the project root, next to `index.html`):
- `audit_app.py`: finds broken links and element IDs used in `script.js` but missing from the HTML
- `check_langs.py`: lists `data-lang` values per page
- `check_roles.py`: checks role-summary panes in `pages/notes.html`

## Project structure
```
index.html, style.css, script.js   frontend
backend/                           FastAPI server, Whisper, analyzer, job manager
assets/icons/favicon.svg           favicon
pages/                             sub-pages (settings, notes, dashboard)
tools/                             frontend audit scripts
acceptance_test_meeting.mp4, test_speech.wav   sample media for the demo button
```
> **Note:** `pages/settings.html`, `pages/notes.html` and `pages/dashboard.html` are linked from the frontend but are not in this repo yet.
